import {Component} from 'angular2/core';
import {Engine} from './../../services/engine/engine';

@Component({
  selector: 'register',
  templateUrl: 'client/app/components/register/register.html',
  inputs: ['myEngine']
})

export class Register{
  public myEngine: Engine;          //Global engine object

  public firstName  : string;       //First name user is typing at that time
  public lastName   : string;       //Last name user is typing at that time
  public login      : string;       //User name user is typing at that time
  public password   : string;       //Password user is typing at that time
  public cred;

  constructor(){
    this.firstName ="" ; this.lastName= ""; this.login = ""; this.password = "";
  }

  //Send the credentials to the engine in JSON format.
  sendRegistration(){
    console.log("Are you registering?");
      this.cred = {"firstName":this.firstName, "lastName":this.lastName,"login":this.login,"password":this.password};
      this.myEngine.register(this.cred);
  }
}
