/// <reference path="../../../../typings/tsd.d.ts"/>        //Type definitions for SocketIO
import {Injectable, Component} from 'angular2/core';
import {Http, HTTP_PROVIDERS, Headers} from 'angular2/http';

@Component({
  viewProviders: [HTTP_PROVIDERS]
})
@Injectable()
export class Engine{

  public loggedIn   : boolean;                  //Variable to keep track of whether the user is logged in or Not
  public socket     : SocketIOClient.Socket;    //Web socket to communicate on the chat
  public headers    = new Headers();            //Header for the post request
  public errorMsg   : string;                   //Error messages sent by by the post request
  public regMsg     : string;                   //Message receieved after registering
  public messages;                             //List of received messages
  public userInfo;                              //Information of the user. Received after logging in.
  public admin      : boolean = false;
  public username   : string;
  
  

  /**
  Initialises the variables. Fills in the userInfo with bogus variables. The headers is appened with content type JSON. This means that The HTTP POST requests send
  JSON values and not url values! Also it already connects to the socket. This means that anyone can send and receive messages.

  */
  constructor(public http: Http){
    this.userInfo = {
      "firstName" : "anirudh",
      "lastName" : "thijs"
    }

    this.errorMsg = "";
    this.loggedIn = false;
    this.headers.append('Content-Type', 'application/json');    //Append HTTP POST header with content type JSON

    this.connectSocket();           //Connect to the chat Socket. This means that anyone can receive and send!
  }

  compare(x: Object, y: Object) : number{
    var x2: any = x;
    var y2: any = y;
    if (x2.date < y2.date)
      return -1;
    if (x2.date > y2.date)
      return 1;
    return 0;
  }

  getMessages(){
    this.http.post('/messagelist', null).subscribe(res => {
        var result: any = res;
        var list = JSON.parse(result._body);
        this.messages = list;
          
          
        document.getElementById('chatbox-main').innerHTML = '';
        for (var i = 0; i < this.messages.length; i++) {
            var messageContent = '<li class="collection-item"><div id="chatbox-username"></div><h5 > </h5>'+ this.messages[i].username +' <div id="chatbox-date"><i style="color:grey;" >'+ this.messages[i].date +'</i></div><div id="chatbox-message">'+ this.messages[i].message +'</div> </li>';
            $("#chatbox-main").append(messageContent);
        }
        
    });
  }

  /**
    Caller: login.ts
    Sends a JSON Object with credentials. This is sent to the server in JSON format. If the server send back error:true, something went wrong and we could not login.
    Otherwise the server sends back the credentials of the user. These credentials are set and the chat console is loaded.
  */
  login(creds : string[]){
    this.http.post('/login',JSON.stringify(creds), {headers: this.headers})
      .subscribe(res => {
                          if(res.json().error === true){
                            this.errorMsg = "Could not login.";
                            this.loggedIn = false;
                          }
                          else{
                            this.errorMsg = "Logged in successfully";
                            this.loggedIn = true;                                 //This boolean allows the chat console to load in the file app.html
                            this.userInfo.firstName = res.json().firstName;
                            this.userInfo.lastName = res.json().lastName;
                            this.admin = res.json().authorisation === 'admin';
                            this.username = res.json().username;
                            this.regMsg= '';
                            this.getMessages();
                          }
                        });
    
    return this.errorMsg;     //!Returns any error messages, but this doesnt work. The return value is called before (!) the response to the POST request is received!
  }

  /**
    Logout function. What this does is simply destroy the user credentials in the browser. There are no sessions involved. Disconnecting the socket does not work.
  */
  logout(){
  //  this.disconnectSocket(); //Doesn't really work.
    this.http.post('/logout', null).subscribe(function (res) {
    });
    this.loggedIn = false;
    this.messages = [];
    this.userInfo = {
      "firstName" : "anirudh",
      "lastName" : "thijs"
    }
  }

  //Sets up the websocket and listens for incoming chats.

  connectSocket(){
    this.socket = io();
    this.socket.on('connect', () => {
      this.socket.on('chat', () => {
        this.getMessages();
       });
    });
  }

  //Emits a message to the server
  sendMessage(mess: string){
    this.http.post('/message', JSON.stringify({message: mess, username: this.username}), { headers: this.headers }).subscribe(function (res) {
    });
    this.socket.emit('chat');
  }

  disconnectSocket(){
    //this.socket.emit('logout');
  }


  //Sends user credentials to the server. The server is responsible for checking whether this is valid. Client side checking is not yet implemented.
  register(creds : string[]){
    this.http.post('/register',JSON.stringify(creds), {headers: this.headers})
      .subscribe(res => {
                          if(res.json().error === true){
                            this.regMsg = "Could not register.";
                          }
                          else{
                           this.regMsg= "Registered";
                          }
                        });
  }

  deleteMsg(){
    this.http.post('/delete', JSON.stringify({}), { headers: this.headers }).subscribe(function (res) {
    });
    this.getMessages();
  }


}
