System.register(['angular2/core', 'angular2/http'], function(exports_1) {
    "use strict";
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, http_1;
    var Engine;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            }],
        execute: function() {
            Engine = (function () {
                /**
                Initialises the variables. Fills in the userInfo with bogus variables. The headers is appened with content type JSON. This means that The HTTP POST requests send
                JSON values and not url values! Also it already connects to the socket. This means that anyone can send and receive messages.
              
                */
                function Engine(http) {
                    this.http = http;
                    this.headers = new http_1.Headers(); //Header for the post request
                    this.admin = false;
                    this.userInfo = {
                        "firstName": "anirudh",
                        "lastName": "thijs"
                    };
                    this.errorMsg = "";
                    this.loggedIn = false;
                    this.headers.append('Content-Type', 'application/json'); //Append HTTP POST header with content type JSON
                    this.connectSocket(); //Connect to the chat Socket. This means that anyone can receive and send!
                }
                Engine.prototype.compare = function (x, y) {
                    var x2 = x;
                    var y2 = y;
                    if (x2.date < y2.date)
                        return -1;
                    if (x2.date > y2.date)
                        return 1;
                    return 0;
                };
                Engine.prototype.getMessages = function () {
                    var _this = this;
                    this.http.post('/messagelist', null).subscribe(function (res) {
                        var result = res;
                        var list = JSON.parse(result._body);
                        _this.messages = list;
                        document.getElementById('chatbox-main').innerHTML = '';
                        for (var i = 0; i < _this.messages.length; i++) {
                            var messageContent = '<li class="collection-item"><div id="chatbox-username"></div><h5 > </h5>' + _this.messages[i].username + ' <div id="chatbox-date"><i style="color:grey;" >' + _this.messages[i].date + '</i></div><div id="chatbox-message">' + _this.messages[i].message + '</div> </li>';
                            $("#chatbox-main").append(messageContent);
                        }
                    });
                };
                /**
                  Caller: login.ts
                  Sends a JSON Object with credentials. This is sent to the server in JSON format. If the server send back error:true, something went wrong and we could not login.
                  Otherwise the server sends back the credentials of the user. These credentials are set and the chat console is loaded.
                */
                Engine.prototype.login = function (creds) {
                    var _this = this;
                    this.http.post('/login', JSON.stringify(creds), { headers: this.headers })
                        .subscribe(function (res) {
                        if (res.json().error === true) {
                            _this.errorMsg = "Could not login.";
                            _this.loggedIn = false;
                        }
                        else {
                            _this.errorMsg = "Logged in successfully";
                            _this.loggedIn = true; //This boolean allows the chat console to load in the file app.html
                            _this.userInfo.firstName = res.json().firstName;
                            _this.userInfo.lastName = res.json().lastName;
                            _this.admin = res.json().authorisation === 'admin';
                            _this.username = res.json().username;
                            _this.regMsg = '';
                            _this.getMessages();
                        }
                    });
                    return this.errorMsg; //!Returns any error messages, but this doesnt work. The return value is called before (!) the response to the POST request is received!
                };
                /**
                  Logout function. What this does is simply destroy the user credentials in the browser. There are no sessions involved. Disconnecting the socket does not work.
                */
                Engine.prototype.logout = function () {
                    //  this.disconnectSocket(); //Doesn't really work.
                    this.http.post('/logout', null).subscribe(function (res) {
                    });
                    this.loggedIn = false;
                    this.messages = [];
                    this.userInfo = {
                        "firstName": "anirudh",
                        "lastName": "thijs"
                    };
                };
                //Sets up the websocket and listens for incoming chats.
                Engine.prototype.connectSocket = function () {
                    var _this = this;
                    this.socket = io();
                    this.socket.on('connect', function () {
                        _this.socket.on('chat', function () {
                            _this.getMessages();
                        });
                    });
                };
                //Emits a message to the server
                Engine.prototype.sendMessage = function (mess) {
                    this.http.post('/message', JSON.stringify({ message: mess, username: this.username }), { headers: this.headers }).subscribe(function (res) {
                    });
                    this.socket.emit('chat');
                };
                Engine.prototype.disconnectSocket = function () {
                    //this.socket.emit('logout');
                };
                //Sends user credentials to the server. The server is responsible for checking whether this is valid. Client side checking is not yet implemented.
                Engine.prototype.register = function (creds) {
                    var _this = this;
                    this.http.post('/register', JSON.stringify(creds), { headers: this.headers })
                        .subscribe(function (res) {
                        if (res.json().error === true) {
                            _this.regMsg = "Could not register.";
                        }
                        else {
                            _this.regMsg = "Registered";
                        }
                    });
                };
                Engine.prototype.deleteMsg = function () {
                    this.http.post('/delete', JSON.stringify({}), { headers: this.headers }).subscribe(function (res) {
                    });
                    this.getMessages();
                };
                Engine = __decorate([
                    core_1.Component({
                        viewProviders: [http_1.HTTP_PROVIDERS]
                    }),
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [http_1.Http])
                ], Engine);
                return Engine;
            })();
            exports_1("Engine", Engine);
        }
    }
});
//# sourceMappingURL=compile.js.map