/// <reference path="../../../../typings/tsd.d.ts"/>

import {Component} from 'angular2/core';
import {Engine} from './../../services/engine/engine';


@Component({
  selector:'login',
  templateUrl:'client/app/components/login/login.html',
  inputs: ['myEngine']
})

export class Login{
    public myEngine : Engine;         //Global engine which contains all the variables and functions of the chat application and user values.
    public errorMsg : string;         //Any error messages which might need to be printed
    public username : string;         //Input username to be sent to the server
    public password : string;         //Input password to be sent to the server
    public result   : Object;

    public creds;                      //Username and password in JSON format

    //TODO : Remove initialisation
    constructor(){
      this.username = "Thijs";       //Just for convenience so that we don't have to type in credentials
      this.password = "secret";

    }

    sendToServer = () => {
      this.creds = {"username" : this.username , "password" :  this.password};    //Convert the username and password to JSON format
      this.myEngine.login(this.creds);                                            //Send the credentials to the engine
      this.creds = {};                                                            //Reset credentials, username and password
      this.username ='';
      this.password ='';


    }
}
