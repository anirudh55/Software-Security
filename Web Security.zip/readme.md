The installation instructions are contained within the report in the 
Appendix.

To run the server, install nodejs and mongo. Run the command 'node 
server.js' in the server directory. The website can be visited at the 
address and port displayed in the terminal.


