The complete code is available at https://github.com/anirudh55/Software-Security, https://c9.io/anirudhge/software_security_thijs_anirudh/ (secure app) and https://c9.io/anirudhge/software_security_thijs_anirudh2/ (insecure app).
The submission does not contain the node_modules which are required by the app! To run the app on localhost, the code must be pulled from github or c9.


The installation instructions are contained within the report in the Appendix.

To run the server, install nodejs and mongo. Run the command 'node server.js' in the server directory. The website can be visited at the address and port displayed in the terminal.
