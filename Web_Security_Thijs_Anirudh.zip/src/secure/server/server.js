/**************************************************/
/**                   Imports                    **/
/**************************************************/
var express      = require('express');
var path         = require('path');
var logger       = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser   = require('body-parser');
var mongoose     = require('mongoose');
var passwordHash = require('password-hash');
var session      = require('client-sessions');
var index        = require('./routes/index');
var randomstring = require("randomstring");
var marked       = require('marked');
var Tokens       = require('csrf');

var app = express();

/**************************************************/
/**           CSRF token initialisation          **/
/**************************************************/
var tokens = new Tokens();

/**************************************************/
/**           IO socket initialisation           **/
/**************************************************/
var server       = require('http').Server(app);
var io           = require('socket.io')(server);

/**************************************************/
/**          View engine initialisation          **/
/**************************************************/
app.set('views', path.join(__dirname));
app.set('view engine', 'ejs');
app.engine('html', require('ejs').renderFile);
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: false
}));
app.use(cookieParser());
app.use('/node_modules', express.static(path.resolve('./node_modules')));
app.use('/client', express.static(path.resolve('./client')));
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', index);

/**************************************************/
/**        Markdown option initialisation        **/
/**************************************************/
marked.setOptions({
  sanitize: true
});

/**************************************************/
/**            Session initialisation            **/
/**************************************************/
app.use(session({
  cookieName: 'session',
  secret: randomstring.generate(),
  duration: 30 * 60 * 1000,
  activeDuration: 5 * 60 * 1000,
  cookie: {
    ephemeral: true,
    httpOnly: true,
    secure: false
  }
}));

/**************************************************/
/**            Database initialisation           **/
/**************************************************/
/** Database connection and variable initialisation */
mongoose.connect('mongodb://localhost/software_security');
var Schema = mongoose.Schema,
    ObjectId = Schema.ObjectId;
    
/** Create user schema, model, and instance */
var userSchema = new Schema({
    firstName    : String,
    lastName     : String,
    username     : {type: String, unique: true},
    password     : String,
    authorisation: String,
    secret       : String
});
var userModel = mongoose.model('User', userSchema);
var admin = new userModel();

/** Set an administrator account upon creation of the database */
admin.firstName     = 'Admin';
admin.lastName      = 'Admin';
admin.username      = 'Admin';
admin.password      = passwordHash.generate('Admin');
admin.authorisation = 'admin';
admin.secret        = '';
admin.save();

/** Create message schema and model */
var messageSchema = new Schema({
    username:   String,
    firstName:  String,
    lastName:   String,
    message:    String,
    date:       {type: Date, default: Date.now}
});
var messageModel = mongoose.model('Message', messageSchema);

/**************************************************/
/**              Register function               **/
/**************************************************/
app.post('/register', function(req, res){
    //if(req.headers.origin == 'https://software-security-thijs-anirudh-anirudhge.c9users.io'){
        var result = false;
        var user = new userModel();
        user.firstName = req.body.firstName;
        user.lastName = req.body.lastName;
        user.username = req.body.login;
        user.password = passwordHash.generate(req.body.password);
        user.authorisation = 'user';
        user.secret = '';
        user.save(function (err){
            if(err){
                res.end(JSON.stringify({error:true}));
            }else{
                res.end(JSON.stringify({error:false}));
            }
        });
    //}
});
    
    
/**************************************************/
/**               Login function                 **/
/**************************************************/
app.post('/login', function(req, res){
    //if(req.headers.origin == 'https://software-security-thijs-anirudh-anirudhge.c9users.io'){
        
        userModel.find({username: req.body.username}, function(err, user){            /** Cannot login */
            if(err || user.length != 1){
                //No user found
                res.end(JSON.stringify({error:true}));
            }else{
                /** Logging in */
                if(passwordHash.verify(req.body.password, user[0].password)){
                    /** Create CSRF token and store it in database. */
                    var my_secret = tokens.secretSync();
                    var token = tokens.create(my_secret);
                    console.log("Secret = " + my_secret);
                    console.log("Token  = " + token);
                    userModel.update({username: req.body.username}, {secret: my_secret}, function(err, naff){
                        var result = user[0];
                        result.secret = "";
                        req.session.user = result;
                        result.secret = token;
                        console.log("Result = " + result);
                        res.end(JSON.stringify(result));
                        return;
                    });
                }
            }
        });
    //}
});

/**************************************************/
/**               Logout function                **/
/**************************************************/
app.post('/logout', function(req, res){
   // if(req.headers.origin == 'https://software-security-thijs-anirudh-anirudhge.c9users.io'){
        userModel.find({username: req.session.user.username}, function(err, user){            /** Cannot login */
            if(err || user.length != 1){
                //No user found
                res.end(JSON.stringify({error:true}));
            }else{
                if(tokens.verify(user[0].secret, req.body.secret)){
                    req.session.reset();
                    res.redirect('/');
                }
            }
         });
   // }
});

/**************************************************/
/**         Retrieve messages function           **/
/**************************************************/
app.post('/messagelist', function(req, res){
    //if(req.headers.origin == 'https://software-security-thijs-anirudh-anirudhge.c9users.io'){
        userModel.find({username: req.session.user.username}, function(err, user){            /** Cannot login */
            if(err || user.length != 1){
                //No user found
                res.end(JSON.stringify({error:true}));
            }else{
                if(tokens.verify(user[0].secret, req.body.secret)){
                    messageModel.find({}, function(err, docs){
                    if(!err)
                        res.json(docs);
                    });
                }
            }
         });
        
   // }
});

/**************************************************/
/**            Send message function             **/
/**************************************************/
app.post('/message', function(req, res){
    if(/*req.headers.origin == 'https://software-security-thijs-anirudh-anirudhge.c9users.io' && */req.session.user){
        userModel.find({username: req.session.user.username}, function(err, user){            /** Cannot login */
            if(err || user.length != 1){
                //No user found
                res.end(JSON.stringify({error:true}));
            }else{
                if(tokens.verify(user[0].secret, req.body.secret)){
                    var message = new messageModel();
                    message.username = req.session.user.username;
                    message.firstName = req.session.user.firstName;
                    message.lastName = req.session.user.lastName;
                    message.message = marked(req.body.message).trim();
                    message.save(function (err){
                        if(err)
                            console.log(err); //TODO message back that message couldn't be stored
                    });
                    res.end(JSON.stringify({error:false}));
                }else
                    res.end(JSON.stringify({error:true}));
            }
         });
        
    }
});

/**************************************************/
/**          Delete messages function            **/
/**************************************************/
app.post('/delete', function(req, res){
    if(/*req.headers.origin == 'https://software-security-thijs-anirudh-anirudhge.c9users.io' && */req.session.user.authorisation === 'admin'){
        userModel.find({username: req.session.user.username}, function(err, user){            /** Cannot login */
            if(err || user.length != 1){
                //No user found
                res.end(JSON.stringify({error:true}));
            }else{
                if(tokens.verify(user[0].secret, req.body.secret)){
                    messageModel.remove({}, function(err) {
                    res.end(JSON.stringify({error:false}));
                    io.to('room').emit('chat');
                    });
                }
            }
         });
        
    }else{
        res.end(JSON.stringify({error:true}));
    }
});


// catch 404 and forward to error handler
app.use(function(req, res, next) {
    var err = new Error('Not Found');
    err.status = 404;
    next(err);
});

server.listen(process.env.PORT, process.env.IP);


//SOCKET IO STUFF
io.on('connection', function (socket) {
  socket.join('room');
  socket.emit('chat', 'You connected successfully');
  socket.on('chat', function () {
    io.to('room').emit('chat');
  });
  socket.on('logout',function(){
    socket.leave('room');
  });
});

module.exports = app;
