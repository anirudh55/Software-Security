import {Component} from 'angular2/core';
import {Engine} from './../../services/engine/engine';

@Component({
  selector:'userInfo',
  template:`
      First Name: {{myEngine.userInfo.firstName}} <br>
      Last Name: {{myEngine.userInfo.lastName}}
  `,
  inputs: ['myEngine']
})

export class UserInfo{
  public myEngine: Engine;
}
