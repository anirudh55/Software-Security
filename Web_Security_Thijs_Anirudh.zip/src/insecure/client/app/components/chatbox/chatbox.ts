/// <reference path="../../../../typings/tsd.d.ts"/>


import {Component} from 'angular2/core';
import {Engine} from './../../services/engine/engine';

@Component({
  selector: 'chatbox',
  templateUrl: 'client/app/components/chatbox/chatbox.html',
  styleUrls: ['client/app/components/chatbox/chatbox.css'],
  inputs: ['myEngine']
})

export class Chatbox{
    public myEngine : Engine;           //Global engine value
    public currentMsg : string = "";    //The message the user is typing in the textbox at that moment.


  send(){
    this.myEngine.sendMessage(this.currentMsg);   //Send the current message to the engine
    this.currentMsg = '';                         //Reset the input value
  }

  logout(){
    this.myEngine.logout();                        //Logout button. Upon logout, notify the engine
  }



}
