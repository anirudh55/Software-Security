import {Component} from 'angular2/core';
import {Login} from './../login/login';
import {Register} from './../register/register';
import {Chatbox} from './../chatbox/chatbox';
import {UserInfo} from './../userInfo/userInfo';

import {Engine} from './../../services/engine/engine';

@Component({
  selector: 'chat-app',
  templateUrl: 'client/app/components/app/app.html',
  directives: [Login, Register, Chatbox, UserInfo],
  providers: [Engine]
})

export class AppComponent{
  public loggedIn : boolean =false;

  constructor(public engine : Engine){

    console.log(engine.loggedIn);
  }
}
