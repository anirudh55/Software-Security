System.register(['angular2/core', './../login/login', './../register/register', './../chatbox/chatbox', './../userInfo/userInfo', './../../services/engine/engine'], function(exports_1) {
    "use strict";
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, login_1, register_1, chatbox_1, userInfo_1, engine_1;
    var AppComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (login_1_1) {
                login_1 = login_1_1;
            },
            function (register_1_1) {
                register_1 = register_1_1;
            },
            function (chatbox_1_1) {
                chatbox_1 = chatbox_1_1;
            },
            function (userInfo_1_1) {
                userInfo_1 = userInfo_1_1;
            },
            function (engine_1_1) {
                engine_1 = engine_1_1;
            }],
        execute: function() {
            AppComponent = (function () {
                function AppComponent(engine) {
                    this.engine = engine;
                    this.loggedIn = false;
                    console.log(engine.loggedIn);
                }
                AppComponent = __decorate([
                    core_1.Component({
                        selector: 'chat-app',
                        templateUrl: 'client/app/components/app/app.html',
                        directives: [login_1.Login, register_1.Register, chatbox_1.Chatbox, userInfo_1.UserInfo],
                        providers: [engine_1.Engine]
                    }), 
                    __metadata('design:paramtypes', [engine_1.Engine])
                ], AppComponent);
                return AppComponent;
            })();
            exports_1("AppComponent", AppComponent);
        }
    }
});
//# sourceMappingURL=app.js.map