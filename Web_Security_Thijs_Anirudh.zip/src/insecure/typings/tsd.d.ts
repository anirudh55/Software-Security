/// <reference path="angular2/angular2.d.ts" />
/// <reference path="es6-promise/es6-promise.d.ts" />
/// <reference path="rx/rx-lite.d.ts" />
/// <reference path="rx/rx.d.ts" />
/// <reference path="socket.io-client/socket.io-client.d.ts" />
