/**************************************************/
/**                   Imports                    **/
/**************************************************/
var express      = require('express');
var path         = require('path');
var logger       = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser   = require('body-parser');
var mongoose     = require('mongoose');
var session      = require('client-sessions');
var index        = require('./routes/index');
var randomstring = require("randomstring");
var marked       = require('marked');

var app = express();

/**************************************************/
/**           IO socket initialisation           **/
/**************************************************/
var server       = require('http').Server(app);
var io           = require('socket.io')(server);

/**************************************************/
/**          View engine initialisation          **/
/**************************************************/
app.set('views', path.join(__dirname));
app.set('view engine', 'ejs');
app.engine('html', require('ejs').renderFile);
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: false
}));
app.use(cookieParser());
app.use('/node_modules', express.static(path.resolve('./node_modules')));
app.use('/client', express.static(path.resolve('./client')));
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', index);

/**************************************************/
/**            Session initialisation            **/
/**************************************************/
app.use(session({
  cookieName: 'session',
  secret: randomstring.generate(),
  duration: 30 * 60 * 1000,
  activeDuration: 5 * 60 * 1000,
  cookie: {
    ephemeral: true,
    httpOnly: true,
    secure: false
  }
}));

/**************************************************/
/**            Database initialisation           **/
/**************************************************/
/** Database connection and variable initialisation */
mongoose.connect('mongodb://localhost/software_security');
var Schema = mongoose.Schema,
    ObjectId = Schema.ObjectId;
    
/** Create user schema, model, and instance */
var userSchema = new Schema({
    firstName    : String,
    lastName     : String,
    username     : {type: String, unique: true},
    password     : String,
    authorisation: String,
});
var userModel = mongoose.model('User', userSchema);
var admin = new userModel();

/** Set an administrator account upon creation of the database */
admin.firstName     = 'Admin';
admin.lastName      = 'Admin';
admin.username      = 'Admin';
admin.password      = 'Admin';
admin.authorisation = 'admin';
admin.save();

/** Create message schema and model */
var messageSchema = new Schema({
    username:   String,
    firstName:  String,
    lastName:   String,
    message:    String,
    date:       {type: Date, default: Date.now}
});
var messageModel = mongoose.model('Message', messageSchema);

/**************************************************/
/**              Register function               **/
/**************************************************/
app.post('/register', function(req, res){
    var user = new userModel();
    user.firstName = req.body.firstName;
    user.lastName = req.body.lastName;
    user.username = req.body.login;
    user.password = req.body.password;
    user.authorisation = req.body.authorisation;
    user.save(function (err){
        if(err){
            res.end(JSON.stringify({error:true}));
        }else{
            res.end(JSON.stringify({error:false}));
        }
    });
});

/**************************************************/
/**               Login function                 **/
/**************************************************/
app.post('/login', function(req, res){
    userModel.find({username: req.body.username}, function(err, user){
        /** Cannot login */
        if(err || user.length != 1){
            console.log("Error, the number of expected users did not match. Number: %d, Expected: 1", user.length);
            res.end(JSON.stringify({error:true}));
        }else{
            /** Logging in */
            if(req.body.password === user[0].password){
              var result = user[0];
              req.session.user = user[0];
              res.end(JSON.stringify(result));
              return;
            }
        }
    });
});

/**************************************************/
/**               Logout function                **/
/**************************************************/
app.post('/logout', function(req, res){
    console.log("Logout csrf");
    req.session.reset();
    res.redirect('/');
});

/**************************************************/
/**         Retrieve messages function           **/
/**************************************************/
app.post('/messagelist', function(req, res){
    messageModel.find({}, function(err, docs){
        if(!err)
            res.json(docs);
    });
});

/**************************************************/
/**            Send message function             **/
/**************************************************/
app.post('/message', function(req, res){
    if(req.session.user){
        var message = new messageModel();
        message.username = req.body.username;
        message.firstName = req.session.user.firstName;
        message.lastName = req.session.user.lastName;
        message.message = marked(req.body.message);
        message.save(function (err){
            if(err)
                console.log(err); //TODO message back that message couldn't be stored
        });
       res.end(JSON.stringify({error:false}));
    }else
       res.end(JSON.stringify({error:true}));
});

/**************************************************/
/**          Delete messages function            **/
/**************************************************/
app.post('/delete', function(req, res){
    if(req.session.user.authorisation === 'admin'){
        messageModel.remove({}, function(err) {
        res.end(JSON.stringify({error:false}));
        io.to('room').emit('chat');
        });
    }else{
        res.end(JSON.stringify({error:true}));
    }
});


// catch 404 and forward to error handler
app.use(function(req, res, next) {
    var err = new Error('Not Found');
    err.status = 404;
    next(err);
});

server.listen(process.env.PORT, process.env.IP);


//SOCKET IO STUFF
io.on('connection', function (socket) {
  console.log("SocketIO: ur connecting");
  socket.join('room');
  socket.emit('chat', 'You connected successfully');
  socket.on('chat', function () {
    io.to('room').emit('chat');
  });
  socket.on('logout',function(){
    console.log("SocketIO: ur disconnecting");
    socket.leave('room');
  });
});

module.exports = app;
